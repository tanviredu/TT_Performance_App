# TT Equipment Hours

একটি lightweight Django application যা terminal truck (TT01–TT18)-এর cumulative hour-meter reading এবং shift handover record করে।

## Features

- Operator এবং Equipment-এর configurable dropdown
- Cumulative reading-এর backend validation: `previous <= current <= previous + 8`
- Decimal hours support
- Initial hours admin-এ configure না করা পর্যন্ত first record বন্ধ রাখা
- Same-reading confirmation এবং duplicate submission protection
- Staff-only reporting page with date, equipment, and operator filters
- Applied filters সহ `.xlsx` export
- Django Admin-এ operators, equipment, এবং hour records পরিচালনা
- Responsive Bangla-first operator interface

## Run locally

```bash
uv sync
cd artifacts/api-server
uv run python manage.py migrate
uv run python manage.py createsuperuser
uv run python manage.py seed_equipment
uv run python manage.py seed_operators
uv run python manage.py runserver
```

Then open `http://127.0.0.1:8000/`.

- Operator entry: `/`
- Staff report: `/report/`
- Django Admin: `/admin/`

Before submitting the first reading for an equipment, sign in to Django Admin and set its `initial_hours`. This prevents the application from guessing an unsafe starting value.

## Tests

```bash
cd artifacts/api-server
uv run python manage.py test equipment
```

## Configuration

- Database: SQLite at `artifacts/api-server/db.sqlite3`
- Time zone: `Asia/Dhaka`
- `SESSION_SECRET`: optional environment secret for deployments
- `DJANGO_DEBUG`: defaults to `true` for local development