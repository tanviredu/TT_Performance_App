(function () {
  const form = document.getElementById("entry-form");
  const equipment = document.getElementById("id_equipment");
  const panel = document.getElementById("reading-panel");
  const previous = document.getElementById("previous-hours");
  const maximum = document.getElementById("maximum-hours");
  const input = document.getElementById("id_total_hours");
  const warning = document.getElementById("client-warning");
  const template = form.dataset.summaryTemplate;

  function showWarning(message) {
    warning.textContent = message;
    warning.hidden = !message;
  }

  async function updateBounds() {
    if (!equipment.value) {
      previous.textContent = "—";
      maximum.textContent = "—";
      panel.classList.remove("configured");
      return;
    }
    try {
      const response = await fetch(template.replace("/0/", `/${equipment.value}/`));
      const data = await response.json();
      if (!data.configured) {
        previous.textContent = "প্রয়োজন";
        maximum.textContent = "—";
        panel.classList.add("unconfigured");
        showWarning(data.message);
        return;
      }
      previous.textContent = `${data.previous} ঘণ্টা`;
      maximum.textContent = `${data.maximum} ঘণ্টা`;
      panel.classList.add("configured");
      showWarning("");
    } catch (_) {
      showWarning("Reading range লোড করা যায়নি। আবার চেষ্টা করুন।");
    }
  }

  equipment.addEventListener("change", updateBounds);
  input.addEventListener("input", function () {
    const min = parseFloat(previous.textContent);
    const max = parseFloat(maximum.textContent);
    const value = parseFloat(input.value);
    if (Number.isFinite(value) && Number.isFinite(min) && Number.isFinite(max)) {
      showWarning(value < min ? "বর্তমান reading আগের reading-এর চেয়ে কম হতে পারবে না।" :
        value > max ? `সর্বোচ্চ গ্রহণযোগ্য reading ${max} ঘণ্টা।` :
        value === min ? "Reading একই আছে — সংরক্ষণের আগে তথ্য যাচাই করুন।" : "");
    }
  });
  form.addEventListener("submit", function (event) {
    const min = parseFloat(previous.textContent);
    const value = parseFloat(input.value);
    if (Number.isFinite(value) && Number.isFinite(min) && value === min &&
        !document.getElementById("id_confirm_same").checked) {
      event.preventDefault();
      showWarning("Reading আগেরটির সমান। checkbox টিক দিয়ে তথ্য যাচাই করুন।");
    }
  });
})();