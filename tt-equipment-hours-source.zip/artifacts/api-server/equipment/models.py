from django.core.validators import MinValueValidator
from django.db import models


class Operator(models.Model):
    operator_id = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=100, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["operator_id"]

    def __str__(self):
        return f"{self.operator_id} — {self.name}" if self.name else self.operator_id


class Equipment(models.Model):
    equipment_id = models.CharField(max_length=10, unique=True)
    initial_hours = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
        help_text="Required before the first operator reading can be saved.",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["equipment_id"]
        verbose_name = "Equipment"
        verbose_name_plural = "Equipment"

    def __str__(self):
        return self.equipment_id


class EquipmentHourRecord(models.Model):
    operator = models.ForeignKey(Operator, on_delete=models.PROTECT, related_name="hour_records")
    equipment = models.ForeignKey(
        Equipment, on_delete=models.PROTECT, related_name="hour_records"
    )
    date = models.DateField()
    total_hours = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date", "-created_at", "-id"]
        indexes = [
            models.Index(fields=["equipment", "-created_at"]),
            models.Index(fields=["date"]),
        ]

    def __str__(self):
        return f"{self.equipment.equipment_id} — {self.total_hours}"