# TT Equipment Hours

Bangla-first Django application for recording cumulative operating hours for terminal truck equipment and operators.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Django app (managed preview port)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `SESSION_SECRET` is provided by the workspace; SQLite is used for local persistence.

## Stack

- Django 5.2, Python 3.13
- Database: SQLite3
- Templates: Django Templates, HTML, CSS, vanilla JavaScript
- Excel export: openpyxl

## Where things live

- Django project: `artifacts/api-server/config`
- Core app: `artifacts/api-server/equipment`
- Business rules: `artifacts/api-server/equipment/services.py`
- Templates/static assets: `artifacts/api-server/equipment/templates` and `artifacts/api-server/equipment/static`
- SQLite database: `artifacts/api-server/db.sqlite3`

## Architecture decisions

- Cumulative readings are validated per equipment, never per operator.
- The first reading requires an admin-configured `initial_hours`; the system never silently assumes zero.
- Submission validation is repeated inside an atomic service boundary immediately before record creation.
- Reporting uses the same filtered queryset for the table and Excel export.

## Product

Operators can quickly submit a TT equipment reading in Bangla. Staff users can audit, filter, and export all recorded handovers.

## Gotchas

- Run `uv sync` before the first Django command.
- Set initial hours from `/admin/` before entering the first reading for each TT.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
