from django.contrib import admin

from .models import Equipment, EquipmentHourRecord, Operator


@admin.register(Operator)
class OperatorAdmin(admin.ModelAdmin):
    list_display = ("operator_id", "name", "is_active")
    list_filter = ("is_active",)
    search_fields = ("operator_id", "name")


@admin.register(Equipment)
class EquipmentAdmin(admin.ModelAdmin):
    list_display = ("equipment_id", "initial_hours", "is_active")
    list_filter = ("is_active",)
    search_fields = ("equipment_id",)


@admin.register(EquipmentHourRecord)
class EquipmentHourRecordAdmin(admin.ModelAdmin):
    list_display = ("id", "date", "equipment", "operator", "total_hours", "created_at")
    list_filter = ("date", "equipment", "operator")
    search_fields = ("equipment__equipment_id", "operator__operator_id")
    date_hierarchy = "date"
    readonly_fields = ("created_at",)