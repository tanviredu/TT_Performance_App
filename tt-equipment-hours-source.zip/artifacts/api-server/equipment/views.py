from io import BytesIO

from django.contrib.admin.views.decorators import staff_member_required
from django.core.exceptions import ValidationError
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.core.paginator import Paginator
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from .forms import ReportFilterForm, ShiftEntryForm
from .models import Equipment, EquipmentHourRecord
from .services import create_hour_record, get_reading_bounds


def entry(request):
    if request.method == "POST":
        form = ShiftEntryForm(request.POST)
        if form.is_valid():
            try:
                record, reading = create_hour_record(
                    operator=form.cleaned_data["operator"],
                    equipment=form.cleaned_data["equipment"],
                    total_hours=form.cleaned_data["total_hours"],
                    confirm_same=form.cleaned_data.get("confirm_same", False),
                )
            except ValidationError as exc:
                form.add_error("total_hours", exc)
            else:
                request.session["last_submission"] = {
                    "record_id": record.pk,
                    "operator": record.operator.operator_id,
                    "equipment": record.equipment.equipment_id,
                    "previous": str(reading.previous),
                    "current": str(record.total_hours),
                    "shift_hours": str(reading.shift_hours),
                }
                return redirect("submission-success")
    else:
        form = ShiftEntryForm()
    return render(request, "equipment/entry.html", {"form": form})


def submission_success(request):
    submission = request.session.get("last_submission")
    if not submission:
        return redirect("entry")
    return render(request, "equipment/success.html", {"submission": submission})


def equipment_summary(request, equipment_id):
    equipment = get_object_or_404(Equipment, pk=equipment_id, is_active=True)
    bounds = get_reading_bounds(equipment)
    if bounds is None:
        return JsonResponse(
            {
                "configured": False,
                "message": "প্রথম রেকর্ডের আগে প্রশাসককে initial hours নির্ধারণ করতে হবে।",
            }
        )
    return JsonResponse(
        {
            "configured": True,
            "previous": str(bounds.previous),
            "maximum": str(bounds.maximum),
            "is_first_record": bounds.is_first_record,
        }
    )


def _filtered_records(request):
    form = ReportFilterForm(request.GET or None)
    queryset = EquipmentHourRecord.objects.select_related("operator", "equipment")
    if form.is_valid():
        values = form.cleaned_data
        if values.get("from_date"):
            queryset = queryset.filter(date__gte=values["from_date"])
        if values.get("to_date"):
            queryset = queryset.filter(date__lte=values["to_date"])
        if values.get("equipment"):
            queryset = queryset.filter(equipment=values["equipment"])
        if values.get("operator"):
            queryset = queryset.filter(operator=values["operator"])
    return form, queryset.order_by("-date", "-created_at", "-id")


@staff_member_required
def report(request):
    form, records = _filtered_records(request)
    page = Paginator(records, 25).get_page(request.GET.get("page"))
    query_params = request.GET.copy()
    query_params.pop("page", None)
    return render(
        request,
        "equipment/report.html",
        {
            "form": form,
            "page": page,
            "records": page.object_list,
            "query_params": query_params.urlencode(),
        },
    )


@staff_member_required
def export_excel(request):
    _, records = _filtered_records(request)
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Equipment Hours"
    headers = [
        "ID",
        "Date",
        "Operator ID",
        "Equipment",
        "Total Hours",
        "Created At",
    ]
    worksheet.append(headers)
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="156B72")
    for record in records:
        worksheet.append(
            [
                record.pk,
                record.date,
                record.operator.operator_id,
                record.equipment.equipment_id,
                float(record.total_hours),
                timezone.localtime(record.created_at).replace(tzinfo=None),
            ]
        )
    for row in worksheet.iter_rows(min_row=2):
        row[1].number_format = "dd-mmm-yyyy"
        row[4].number_format = "0.00"
        row[5].number_format = "dd-mmm-yyyy hh:mm"
    for column_cells in worksheet.columns:
        width = max(len(str(cell.value or "")) for cell in column_cells) + 2
        worksheet.column_dimensions[get_column_letter(column_cells[0].column)].width = min(
            width, 28
        )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    response = HttpResponse(
        output.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    response["Content-Disposition"] = (
        f'attachment; filename="equipment-hours-{timezone.localdate().isoformat()}.xlsx"'
    )
    return response