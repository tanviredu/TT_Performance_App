from decimal import Decimal

from django import forms
from django.core.exceptions import ValidationError

from .models import Equipment, Operator
from .services import get_reading_bounds, validate_cumulative_hours


class ShiftEntryForm(forms.Form):
    operator = forms.ModelChoiceField(
        queryset=Operator.objects.none(),
        empty_label="অপারেটর নির্বাচন করুন",
        label="Operator ID",
    )
    equipment = forms.ModelChoiceField(
        queryset=Equipment.objects.none(),
        empty_label="Equipment নির্বাচন করুন",
        label="Equipment",
    )
    total_hours = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        min_value=Decimal("0"),
        label="Cumulative Hours",
        widget=forms.NumberInput(
            attrs={
                "placeholder": "যেমন 118 বা 118.5",
                "step": "0.01",
                "min": "0",
                "inputmode": "decimal",
            }
        ),
    )
    confirm_same = forms.BooleanField(
        required=False,
        label="আগের রিডিং একই আছে — আমি তথ্য যাচাই করেছি",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["operator"].queryset = Operator.objects.filter(is_active=True)
        self.fields["equipment"].queryset = Equipment.objects.filter(is_active=True)

    def clean_operator(self):
        operator = self.cleaned_data["operator"]
        if not operator.is_active:
            raise ValidationError("এই অপারেটর বর্তমানে সক্রিয় নয়।")
        return operator

    def clean_equipment(self):
        equipment = self.cleaned_data["equipment"]
        if not equipment.is_active:
            raise ValidationError("এই Equipment বর্তমানে সক্রিয় নয়।")
        return equipment

    def clean_total_hours(self):
        value = self.cleaned_data["total_hours"]
        if value < 0:
            raise ValidationError("সময় অবশ্যই শূন্য বা তার বেশি হতে হবে।")
        return value

    def clean(self):
        cleaned_data = super().clean()
        equipment = cleaned_data.get("equipment")
        total_hours = cleaned_data.get("total_hours")
        if equipment and total_hours is not None:
            try:
                validate_cumulative_hours(equipment, total_hours)
            except ValidationError as exc:
                self.add_error("total_hours", exc)
        return cleaned_data


class ReportFilterForm(forms.Form):
    from_date = forms.DateField(
        required=False,
        label="From Date",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    to_date = forms.DateField(
        required=False,
        label="To Date",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    equipment = forms.ModelChoiceField(
        required=False,
        queryset=Equipment.objects.none(),
        empty_label="সব Equipment",
        label="Equipment",
    )
    operator = forms.ModelChoiceField(
        required=False,
        queryset=Operator.objects.none(),
        empty_label="সব Operator",
        label="Operator",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["equipment"].queryset = Equipment.objects.all()
        self.fields["operator"].queryset = Operator.objects.all()

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get("from_date")
        end = cleaned_data.get("to_date")
        if start and end and start > end:
            raise ValidationError("From Date অবশ্যই To Date-এর আগে হতে হবে।")
        return cleaned_data