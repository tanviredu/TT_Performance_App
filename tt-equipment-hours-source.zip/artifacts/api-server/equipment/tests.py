from decimal import Decimal

from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from django.test import Client, TestCase

from .models import Equipment, EquipmentHourRecord, Operator
from .services import create_hour_record, validate_cumulative_hours


class CumulativeHoursTests(TestCase):
    def setUp(self):
        self.operator = Operator.objects.create(operator_id="OP001")
        self.other_operator = Operator.objects.create(operator_id="OP002")
        self.tt01 = Equipment.objects.create(equipment_id="TT01", initial_hours=Decimal("110"))
        self.tt02 = Equipment.objects.create(equipment_id="TT02", initial_hours=Decimal("90"))
        EquipmentHourRecord.objects.create(
            operator=self.operator,
            equipment=self.tt01,
            date="2026-09-24",
            total_hours=Decimal("118"),
        )

    def test_accepts_exactly_eight_hours(self):
        reading = validate_cumulative_hours(self.tt01, Decimal("126"))
        self.assertEqual(reading.shift_hours, Decimal("8"))

    def test_accepts_same_reading(self):
        reading = validate_cumulative_hours(self.tt01, Decimal("118"))
        self.assertEqual(reading.shift_hours, Decimal("0"))

    def test_accepts_partial_shift(self):
        reading = validate_cumulative_hours(self.tt01, Decimal("124"))
        self.assertEqual(reading.shift_hours, Decimal("6"))

    def test_rejects_lower_reading(self):
        with self.assertRaisesMessage(ValidationError, "বর্তমান সময় এর চেয়ে কম হতে পারবে না"):
            validate_cumulative_hours(self.tt01, Decimal("117"))

    def test_rejects_more_than_eight_hours(self):
        with self.assertRaisesMessage(ValidationError, "সর্বোচ্চ গ্রহণযোগ্য সময় 126"):
            validate_cumulative_hours(self.tt01, Decimal("127"))

    def test_accepts_decimal_readings(self):
        self.tt01.hour_records.update(total_hours=Decimal("118.5"))
        reading = validate_cumulative_hours(self.tt01, Decimal("126.5"))
        self.assertEqual(reading.shift_hours, Decimal("8"))

    def test_entry_page_and_equipment_summary(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        summary = self.client.get(f"/equipment/{self.tt01.pk}/summary/")
        self.assertEqual(summary.json()["previous"], "118.00")
        self.assertEqual(summary.json()["maximum"], "126.00")

    def test_submission_and_duplicate_protection(self):
        response = self.client.post(
            "/",
            {
                "operator": self.other_operator.pk,
                "equipment": self.tt02.pk,
                "total_hours": "98",
            },
        )
        self.assertRedirects(response, "/success/")
        duplicate = self.client.post(
            "/",
            {
                "operator": self.other_operator.pk,
                "equipment": self.tt02.pk,
                "total_hours": "98",
            },
        )
        self.assertEqual(duplicate.status_code, 200)
        self.assertContains(duplicate, "একই Cumulative Hours ইতোমধ্যে জমা দেওয়া হয়েছে")

    def test_report_and_export_require_staff(self):
        self.assertEqual(self.client.get("/report/").status_code, 302)
        staff = get_user_model().objects.create_user(
            username="reporter", password="strong-test-password", is_staff=True
        )
        self.client.force_login(staff)
        self.assertEqual(self.client.get("/report/").status_code, 200)
        export = self.client.get("/report/export/?equipment=1")
        self.assertEqual(export.status_code, 200)
        self.assertEqual(
            export["Content-Type"],
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )