from dataclasses import dataclass
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import Equipment, EquipmentHourRecord, Operator

SHIFT_HOURS = Decimal("8")


@dataclass(frozen=True)
class HourReading:
    previous: Decimal
    maximum: Decimal
    shift_hours: Decimal
    is_first_record: bool


def latest_record(equipment: Equipment):
    return (
        EquipmentHourRecord.objects.filter(equipment=equipment)
        .select_related("operator", "equipment")
        .order_by("-created_at", "-id")
        .first()
    )


def get_reading_bounds(equipment: Equipment) -> HourReading | None:
    record = latest_record(equipment)
    if record:
        previous = record.total_hours
        return HourReading(previous, previous + SHIFT_HOURS, Decimal("0"), False)
    if equipment.initial_hours is None:
        return None
    previous = equipment.initial_hours
    return HourReading(previous, previous + SHIFT_HOURS, Decimal("0"), True)


def validate_cumulative_hours(equipment: Equipment, new_hours: Decimal) -> HourReading:
    bounds = get_reading_bounds(equipment)
    if bounds is None:
        raise ValidationError(
            "এই Equipment-এর প্রাথমিক মোট সময় প্রশাসককে আগে নির্ধারণ করতে হবে।"
        )
    if new_hours < bounds.previous:
        raise ValidationError(
            f"ভুল তথ্য! পূর্ববর্তী মোট সময় ছিল {bounds.previous} ঘণ্টা। "
            "বর্তমান সময় এর চেয়ে কম হতে পারবে না।"
        )
    if new_hours > bounds.maximum:
        raise ValidationError(
            "ভুল তথ্য! বর্তমান শিফটে সর্বোচ্চ 8 ঘণ্টা যোগ করা যাবে। "
            f"সর্বোচ্চ গ্রহণযোগ্য সময় {bounds.maximum} ঘণ্টা।"
        )
    return HourReading(
        bounds.previous,
        bounds.maximum,
        new_hours - bounds.previous,
        bounds.is_first_record,
    )


@transaction.atomic
def create_hour_record(
    *,
    operator: Operator,
    equipment: Equipment,
    total_hours: Decimal,
    confirm_same: bool = False,
) -> tuple[EquipmentHourRecord, HourReading]:
    # SQLite serializes writes; select_for_update provides row locking on databases
    # that support it and documents the intended concurrency boundary.
    equipment = Equipment.objects.select_for_update().get(pk=equipment.pk)
    bounds = get_reading_bounds(equipment)
    if bounds is None:
        raise ValidationError(
            "এই Equipment-এর প্রাথমিক মোট সময় প্রশাসককে আগে নির্ধারণ করতে হবে।"
        )
    reading = validate_cumulative_hours(equipment, total_hours)
    duplicate = (
        EquipmentHourRecord.objects.filter(
            operator=operator, equipment=equipment, total_hours=total_hours
        )
        .order_by("-created_at", "-id")
        .first()
    )
    if duplicate:
        raise ValidationError(
            "এই Equipment-এর জন্য একই Cumulative Hours ইতোমধ্যে জমা দেওয়া হয়েছে। "
            "অনুগ্রহ করে তথ্য যাচাই করুন।"
        )
    if total_hours == reading.previous and not confirm_same:
        raise ValidationError(
            "বর্তমান মোট সময় আগের রিডিংয়ের সমান। তথ্য যাচাই করে আবার নিশ্চিত করুন।"
        )
    record = EquipmentHourRecord.objects.create(
        operator=operator,
        equipment=equipment,
        date=timezone.localdate(),
        total_hours=total_hours,
    )
    return record, HourReading(
        reading.previous, reading.maximum, reading.shift_hours, reading.is_first_record
    )