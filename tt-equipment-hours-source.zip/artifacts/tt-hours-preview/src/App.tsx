function App() {
  return (
    <iframe
      className="live-app-frame"
      src="/"
      title="TT Equipment Hours"
    />
  );
}

export default App;
