from django.urls import path

from . import views

urlpatterns = [
    path("", views.entry, name="entry"),
    path("success/", views.submission_success, name="submission-success"),
    path("equipment/<int:equipment_id>/summary/", views.equipment_summary, name="equipment-summary"),
    path("report/", views.report, name="report"),
    path("report/export/", views.export_excel, name="export-excel"),
]