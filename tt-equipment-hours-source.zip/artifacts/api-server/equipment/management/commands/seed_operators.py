from django.core.management.base import BaseCommand

from equipment.models import Operator


class Command(BaseCommand):
    help = "Create five starter operator IDs; administrators can edit them later."

    def handle(self, *args, **options):
        created = 0
        for number in range(1, 6):
            _, was_created = Operator.objects.get_or_create(
                operator_id=f"OP{number:03d}",
                defaults={"is_active": True},
            )
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Operators ready. Created {created} new records."))