from django.core.management.base import BaseCommand

from equipment.models import Equipment


class Command(BaseCommand):
    help = "Create the fixed TT01–TT18 equipment list without duplicates."

    def handle(self, *args, **options):
        created = 0
        for number in range(1, 19):
            _, was_created = Equipment.objects.get_or_create(
                equipment_id=f"TT{number:02d}",
                defaults={"is_active": True},
            )
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Equipment ready. Created {created} new records."))