from decimal import Decimal

from django.core.exceptions import ValidationError
from django.test import TestCase

from .models import Equipment, EquipmentHourRecord, Operator
from .services import validate_cumulative_hours


class CumulativeHourValidationTests(TestCase):
    def setUp(self):
        self.operator = Operator.objects.create(operator_id="TEST001")
        self.equipment = Equipment.objects.create(
            equipment_id="QA01", initial_hours=Decimal("110")
        )
        EquipmentHourRecord.objects.create(
            operator=self.operator,
            equipment=self.equipment,
            previous_hours=Decimal("110"),
            total_hours=Decimal("118"),
            shift_hours=Decimal("8"),
        )

    def test_accepts_eight_hours(self):
        bounds = validate_cumulative_hours(
            self.equipment, Decimal("126"), self.operator
        )
        self.assertEqual(bounds.previous, Decimal("118"))

    def test_accepts_same_reading(self):
        bounds = validate_cumulative_hours(
            self.equipment,
            Decimal("118"),
            Operator.objects.create(operator_id="TEST003"),
        )
        self.assertEqual(bounds.maximum, Decimal("126"))

    def test_accepts_partial_shift(self):
        validate_cumulative_hours(self.equipment, Decimal("124"), self.operator)

    def test_rejects_lower_reading(self):
        with self.assertRaisesMessage(
            ValidationError,
            "বর্তমান সময় এর চেয়ে কম হতে পারবে না",
        ):
            validate_cumulative_hours(self.equipment, Decimal("117"), self.operator)

    def test_rejects_more_than_eight_hours(self):
        with self.assertRaisesMessage(
            ValidationError,
            "সর্বোচ্চ গ্রহণযোগ্য সময় 126 ঘণ্টা",
        ):
            validate_cumulative_hours(self.equipment, Decimal("127"), self.operator)

    def test_accepts_decimal_readings(self):
        decimal_equipment = Equipment.objects.create(
            equipment_id="QA03", initial_hours=Decimal("118.5")
        )
        validate_cumulative_hours(
            decimal_equipment,
            Decimal("126.5"),
            operator=Operator.objects.create(operator_id="TEST002"),
        )

    def test_equipment_readings_are_independent(self):
        other = Equipment.objects.create(
            equipment_id="QA02", initial_hours=Decimal("90")
        )
        bounds = validate_cumulative_hours(other, Decimal("98"), self.operator)
        self.assertEqual(bounds.previous, Decimal("90"))


class EntryViewTests(TestCase):
    def test_entry_has_active_choices(self):
        Operator.objects.create(operator_id="TEST001", is_active=True)
        Operator.objects.create(operator_id="TEST002", is_active=False)
        Equipment.objects.create(equipment_id="QA01", initial_hours=Decimal("110"))
        response = self.client.get("/")
        self.assertContains(response, "TEST001")
        self.assertNotContains(response, "TEST002")